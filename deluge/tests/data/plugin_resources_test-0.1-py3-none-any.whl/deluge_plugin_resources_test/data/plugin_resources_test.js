/**
 * Script: plugin_resources_test.js
 *     The client-side javascript code for the plugin_resources_test plugin.
 *
 * Copyright:
 *     (C) Gregorio Litenstein 2024 <g.litenstein@gmail.com>
 *
 *     This file is part of plugin_resources_test and is licensed under GNU GPL 3.0, or
 *     later, with the additional special exception to link portions of this
 *     program with the OpenSSL library. See LICENSE for more details.
 */

plugin_resources_testPlugin = Ext.extend(Deluge.Plugin, {
    constructor: function(config) {
        config = Ext.apply({
            name: 'plugin_resources_test'
        }, config);
        plugin_resources_testPlugin.superclass.constructor.call(this, config);
    },

    onDisable: function() {
        deluge.preferences.removePage(this.prefsPage);
    },

    onEnable: function() {
        this.prefsPage = deluge.preferences.addPage(
            new Deluge.ux.preferences.plugin_resources_testPage());
    }
});
new plugin_resources_testPlugin();
